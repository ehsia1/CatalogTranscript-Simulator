/* Evan Hsia, ehsia1, Homework 3 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "hw3.h"

int getLines(FILE *in)
{
	char temp[100] = {'\0'};
	int count = 0;
	while (fgets(temp, 100, in) != NULL) {
		count++;
	}
	return count;
}
//void addNode(struct node *head, struct courseID *course, char id[], char term[], int lines)


/*void reorderList(struct node *cur) //recursive
{
	struct node *first = cur;
	struct node *reorder = cur;
	for (int j = 0; j < 10000; j++) {
		while (cur->next != NULL) {
			char temp[7] = {'\0'};
			strcpy(temp, cur->term);
			char yearChar[5] = {'0'};
			for (int i = 0; i < 4; i++) {
				yearChar[i] = temp[i];
			}
			int year = atoi(yearChar);
			char semester[2] = {'\0'};
			semester[0] = temp[5];

			if (semester[0] == 'F') {
				if (year == j) {
					reorder->next = cur;
				}
			}

			if (semester[0] == 'S') {
				if (year == j) {
					reorder->next = cur;
				}
			}
			cur = cur->next;
			reorder = cur;
			reorderList(reorder); //how does this work
		}
		cur = first;
	}
	cur = reorder;
}*/

/*struct node *reorderList(struct node *cur)
{
	struct node *temp1, *temp2, *newHead, *prev, *first;
	newHead = NULL;
	while (cur != NULL) {
		prev = NULL;
		first = temp1 = cur;
		temp2 = cur->next;
		while (temp2 != NULL) { //compare two nodes at a time, taking the first node of cur and comparing with all others
			char temp[7] = {'\0'};
                        strcpy(temp, temp2->term);
                        char yearChar[5] = {'0'};
                        for (int i = 0; i < 4; i++) {
                                yearChar[i] = temp[i];
                        }
                        int yearNext = atoi(yearChar);
                        char semesterNext[2] = {'\0'};
                        semesterNext[0] = temp[5];

			strcpy(temp, first->term);
			for (int i = 0; i < 4; i++) {
				yearChar[i] = temp[i];
			}
			int yearNow = atoi(yearChar);
			char semesterNow[2] = {'\0'};
			semesterNow[0] = temp[5];

			if (yearNow > yearNext) {
				first = temp2;
				prev = temp1;
			}
			temp1 = temp2;
			temp2 = temp2->next;
		}

		if (prev == NULL) { //allows the loop to go through again
			cur = first->next;
		} else { //creates a new link
			prev->next = first->next;
		}
		first->next = NULL;
		if (newHead == NULL) {
			newHead = first;
		} else { //finishes the sorting by pushing the nodes down the line in newHead
			temp1 = newHead;
			while (temp1->next != NULL) {
				temp1 = temp1->next;
			}
			temp1->next = first;
		}
	}
	return newHead;
}*/

int main(int argc, char* argv[])
{
	if (argc == 1) {
		return 1;
	}

	FILE *in = fopen(argv[1], "r");
	int lines = getLines(in);

	struct courseID *course = malloc(lines * sizeof(struct courseID));
	rewind(in);
	char *pos;
	for (int i = 0; i < lines; i++) {
		fgets(course[i].division, 3, in);
		char point[2] = {'\0'};
		fgets(point, 2, in);
		char temp[4] = {'\0'};
		fgets(temp, 4, in);
		course[i].courseDep = atoi(temp);
		fgets(point, 2, in);
		fgets(temp, 4, in);
		course[i].courseNum = atoi(temp);
		fgets(point, 2, in);
		fgets(temp, 4, in);
		course[i].credit = atof(temp);
		fgets(point, 2, in);
		fgets(course[i].title, 33, in);
		if ((pos = strchr(course[i].title, '\n')) != NULL) {
			*pos = '\0';
		}
	}
	fclose(in);
	char user[100] = {'\0'};
	char user2[100] = {'\0'};
	char input = 'm';
	struct node *head = NULL;
	struct node *temp;
	while (input != 'Q') {
		puts("Please enter your choice: ");
		fgets(user, 100, stdin);
		user[0] = toupper(user[0]);
		switch (user[0]) {
			case 'Q': //quit
				while (head != NULL) {
					temp = head->next;
					free(head);
					head = temp;
				}
				free(course);
				input = 'Q';
				break;
			case 'P': //print catalog
				printCatalog(course, lines);
				break;
			case 'C': //print course
				puts("Please enter the course identifier (xx.ddd.nnn): ");
				fgets(user, 100, stdin);
				for (int i = 0; i < 100; i++) {
					user[i] = toupper(user[i]);
				}
				specCourse(course, lines, user);
				break;
			case 'T': //change title
				puts("Please enter the course identifier (xx.ddd.nnn): ");
				fgets(user, 100, stdin);
				for (int i = 0; i < 100; i++) {
                                        user[i] = toupper(user[i]);
                                }
				puts("Please enter the desired course title (32 characters max): ");
				fgets(user2, 33, stdin);
				newTitle(course, lines, user, user2, head);
				break;
			case 'R': //change credit
				puts("Please enter the course identifier (xx.ddd.nnn): ");
				fgets(user, 100, stdin);
				for (int i = 0; i < 100; i++) {
					user[i] = toupper(user[i]);
				}
				puts("Please enter the desired credits: ");
				fgets(user2, 100, stdin);
				newCredit(course, lines, user, user2, head);
				break;
			case 'A': //add to transcript
				puts("Please enter the course identifier (xx.ddd.nnn): ");
				fgets(user, 100, stdin);
				for (int i = 0; i < 100; i++) {
					user[i] = toupper(user[i]);
				}
				puts("Please enter the semester and grade (yyyy.s Gg): ");
				fgets(user2, 100, stdin);
				for (int j = 0; j < 100; j++) {
					user2[j] = toupper(user2[j]);
				}
				head = new_node(user, user2, course, lines, head); //need to send in a pointer to head and add things in order
				break;
			case 'D': //remove from transcript
				puts("Please enter the course identifier (xx.ddd.nnn): ");
				fgets(user, 100, stdin);
				for (int i = 0; i < 100; i++) {
					user[i] = toupper(user[i]);
				}
				puts("Please enter the semester(yyyy.s): ");
				fgets(user2, 100, stdin);
				for (int j = 0; j < 100; j++) {
					user2[j] = toupper(user2[j]);
				}
				head = remove_node(user, user2, head);
				break;
			case 'I': //print transcript
				printTranscript(head);
				break;
			case 'O': //print course from transcript
				puts("Please enter the course identifier (xx.ddd.nnn): ");
				fgets(user, 100, stdin);
				for (int i = 0; i < 100; i++) {
					user[i] = toupper(user[i]);
				}
				transCourse(user, head);
				break;
			case 'G': //calculate gpa
				calcGPA(head);
				break;
			default:
				puts("Invalid menu choice.");
				break;

		}
	}
	return 0;
}
